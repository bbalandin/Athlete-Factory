from flask_wtf import FlaskForm, RecaptchaField
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, EmailField, BooleanField
from wtforms.validators import DataRequired


class AnthropometryForm(FlaskForm):
    height = StringField('Ваш рост', validators=[DataRequired()])
    weight = StringField('Ваш вес')
    waist = StringField('Обхват Вашей талии')
    hip_girth = StringField('Обхват Ваших бёдер')
    bust = StringField('Обхват Вашей груди')
    is_private = BooleanField("Личное")
    submit = SubmitField('Войти')


class AnthropometryGetForm(FlaskForm):
    date_str = StringField('Введите дату', validators=[DataRequired()])
    submit = SubmitField('Получить данные')
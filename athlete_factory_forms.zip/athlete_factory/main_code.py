from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def start():
    return render_template('my_training.html')

@app.route('/my_training')
def my_training():
    return render_template('my_training.html')

@app.route('/anthropometry')
def anthropometry():
    return render_template('anthropometry.html')

@app.route('/catalog')
def catalog():
    return render_template('catalog.html')

@app.route('/player')
def player():
    return render_template('player.html')

@app.route('/base_training')
def base_training():
    return render_template('promo_form.html')

@app.route('/fat_burning_training')
def fat_burning_training():
    return render_template('promo_form_burn.html')

@app.route('/power_training')
def power_training():
    return render_template('promo_form_power.html')




if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')